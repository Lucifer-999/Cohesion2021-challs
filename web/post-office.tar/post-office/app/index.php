<html>
<head>
	<style>
		body{
			background-color: #000000;
			color: #ffffff;
			
		}
		button{
			font-size: 20px;
			background-color: #000000;
			color: #ffffff;
			margin: 50px;
		}
	</style>
	<title>
		Post Office
		<?php if(isset($_GET['counter']))
			{	echo '| Counter ' ,$_GET['counter'];		}
		?>
	</title>
</head>
<body>
	<center>
		<h1>Welcome to Post Office</h1>
		<br/><br/>
		<?php if(isset($_GET['read'])): ?>
			<h2> Nothing's here. </h2>
			<form METHOD="GET">
					<button type='submit' name='counter' value=1>Counter 1</button>
			</form>
		<?php else: ?>
			<?php if(!isset($_GET['counter'])): ?>
				<h2>Go to counter 22 to read the letter.</h2>
				<br/><br/>
				<h3>Click below to go to counter 1.</h3>
				<form METHOD="GET">
					<button type='submit' name='counter' value=1>Counter 1</button>
				</form>
			<?php else: ?>
				<?php if($_GET['counter']!=22): ?>
					<h2>Go to the another counter.	</h2>
				<?php else: ?>
					<h2>Click  the button below. </h2>
					<form method="GET">
						<button type='submit' name='read' value='flag'>Read The Letter</button>
					</form>
					<?php if((isset($_POST['read']))&&($_POST['read']=='flag')): ?>	
							The flag is  Y0u_h4v3_G0T_m41l
					<?php endif; ?>
				<?php endif; ?>
				<form METHOD="GET">
					<button type='submit' name='counter' value=<?php echo $_GET['counter']-1 ?>>&lt;- Counter <?php echo $_GET['counter']-1 ?></button>
					<button type='submit' name='counter' value=<?php echo $_GET['counter']+1 ?>>Counter <?php echo $_GET['counter']+1 ?> -&gt;</button>
				</form>
			<?php endif; ?>
		<?php endif; ?>
		<br/><br/><br/>
		<h5>Remember: This is a POST OFFICE...</h5>
	</center>
</body>
</html>
