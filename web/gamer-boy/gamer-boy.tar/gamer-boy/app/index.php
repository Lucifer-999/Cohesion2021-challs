<?php

$servername = "localhost";
$username = "webmaster";
$password = "webmaster54321";
$dbname = "web";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['query'])) {
	$query = $_GET['query'];
	$query = str_replace("'", "\'", $query);
	$query = str_replace('"', '\"', $query);
	$sql = "SELECT * FROM console WHERE Name LIKE \"%" . $query . "%\" ORDER BY Name;";
	$result = $conn->query($sql);
//	echo $result . $_GET['query'];
}
?>

<!DOCTYPE html>
<html class="" lang="en"><head>
    <head>
        <meta charset="UTF-8">

        <link rel="shortcut icon" href="./favicon.ico">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito">
        <link rel="stylesheet" href="style.css">

        <title>Vaccinaion</title>

    </head>

    <body>

        <div class="title" align="center">
            Games List
        </div>

        <div id="cover">
            <form method="get" action="">
                <div class="tb">
                    <div class="td"><input type="text" placeholder="Search" required="" name="query"></div>
                    <div class="td" id="s-cover">
                    <button type="submit">
                        <div id="s-circle"></div>
                        <span></span>
                    </button>
                    </div>
                </div>
            </form>
        </div>
	<?php
	if (isset($_GET['query'])) {	?>
		<h2 align=center style="color:#ffffff;font-size:28px;">You searched for: <?php echo $_GET['query']; ?></h2>
		<div>
			<table class="tab">
				<tr>
					<th>Name</th>
					<th>Plateform</th>
			<th>Publisher</th>
					<th class=last>Year</th>
				</tr>
		<?php
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
		?>
				<tr>
					<td class=res><?php echo $row["Name"]; ?></td>
					<td class=res><?php echo $row["Platform"]; ?></td>
			<td class=res><?php echo $row["Publisher"]; ?></td>
					<td class="res last"><?php echo $row["Year"]; ?></td>
				</tr>
		<?php } } ?>
				</table>
		</div>
	<?php } ?>
    </body>
</html>
