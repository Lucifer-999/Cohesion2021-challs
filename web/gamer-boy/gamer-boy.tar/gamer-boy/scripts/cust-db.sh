#!/bin/bash

/usr/bin/mysqld_safe > /dev/null 2>&1 &

RET=1
while [[ RET -ne 0 ]]; do
    echo "=> Waiting for confirmation of MySQL service startup"
    sleep 5
    mysql -uroot -e "status" > /dev/null 2>&1
    RET=$?
done

mysql -u root -e "create database web;"
mysql -u root web < /db.sql

mysql -u root -e "CREATE USER 'webmaster'@'localhost' IDENTIFIED BY 'webmaster54321';"
mysql -u root -e "GRANT SELECT ON web.console TO 'webmaster'@'localhost';"
mysql -u root -e "GRANT SELECT ON web.hidden TO 'webmaster'@'localhost';"
