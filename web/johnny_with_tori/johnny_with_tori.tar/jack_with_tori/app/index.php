<?php
    setcookie("Authorisation", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiZ3Vlc3QifQ.PZV3taOXqpJMvl2EYeAH-EboOiwXP7nyPU6rGu3ntSs", time()+3600);
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
        <link rel="shortcut icon" href="./favicon.ico">
        <link rel="stylesheet" type="text/css" href="css/normalize.css" />
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/component.css" />
    </head>
    <title>
        MeuSec | Me & You Secure
    </title>
	<body>
		<div class="container demo-3">
			<div class="content">
                <div id="large-header" class="large-header">
                    <canvas id="demo-canvas"></canvas>
                    <h1 class="main-title" style="text-transform: none;">MeuSec</span></h1>
                </div>
                
            </div>
            
		</div>
        <script src="js/TweenLite.min.js"></script>
        <script src="js/EasePack.min.js"></script>
        <script src="js/rAF.js"></script>
        <script src="js/demo.js"></script>
	</body>
</html>