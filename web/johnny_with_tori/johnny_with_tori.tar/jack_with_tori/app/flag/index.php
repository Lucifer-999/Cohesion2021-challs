<?php
  $user = 1;
  $logged = false;
  if(isset($_COOKIE['Authorisation'])) {
    if ($_COOKIE['Authorisation'] == "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiZ3Vlc3QifQ.PZV3taOXqpJMvl2EYeAH-EboOiwXP7nyPU6rGu3ntSs") {
      $logged = true;
    }
    elseif ($_COOKIE['Authorisation'] == "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoibXlzdG9nM24ifQ.Yh-tqFfWZLR17ZxQr_bBIYqMP-Sm6abvfSBMRAkALVU") {
      $logged = true;
      $user = 2;
    }
}
?>
<html>
    <head>
        <title>
          User Details | MeuSec
        </title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="shortcut icon" href="../favicon.ico">
    </head>
    <body>
        <section>
            <!--for demo wrap-->
            <h1>User Details</h1>
            <div class="tbl-header">
              <table cellpadding="0" cellspacing="0">
                <thead>
                  <tr>
                    <th>Key</th>
                    <th>Value</th>
                  
                  </tr>
                </thead>
              </table>
            </div>
            <div class="tbl-content">
              <table cellpadding="0" cellspacing="0">
                <tbody>

                  <tr>
                    <td>User</td>
                    <td>
                      <?php 
                        if ( $user == 1 ) { echo "Guest"; }
                        elseif ( $user == 2 ) { echo "mystog3n"; }
                      ?>
                    </td>
                  </tr>

                  <tr>
                    <td>Logged In</td>
                    <td>
                      <?php 
                        if ($logged) { echo "True";  }
                        else {  echo "False"; }
                      ?>
                    </td>
                  </tr>

                  <tr>
                    <td>Flag</td>
                    <td><input value=
                      "<?php 
                        if (!$logged) {
                          if ( $user == 1 ) { echo "bjB0X3RIM19jMHJyM2N0LUZsNGc="; }
                          elseif ( $user == 2 ) { echo "SndUX3QwazNOX3QwX1RoM193MW4="; }
                        }
                      ?>"
                    type=password readonly disabled></td>
                  </tr>

                </tbody>
              </table>
            </div>
        </section>
        <script src="script.js"></script>
    </body>
</html>
